Name: DongWon Park
Worked with: Alone
Notes:

This is for the Extra Credit 1

Mine works well up to 200 minisupport. Below that may runs the program for a quite long time.
With congress_train.csv, mini support of 200   : 5 seconds
With congress_train.csv, mini support of > 200 : less than 1 second
Confidence level is set to 0.8