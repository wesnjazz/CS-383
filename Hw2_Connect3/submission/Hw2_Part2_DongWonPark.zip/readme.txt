Name: DongWon Park
Favorite ice cream: Vanilla from baskin robbins 31
Work with whom: Alone, by myself
Notes:
	It seems everything works fine so far.
	I didn't build any trees or nodes..instead, I used states and actions as arguments as described in the algorithm and so that it build a kind of virtual tree/nodes.
	I hope this will be fine.
	